class Subject {
    constructor(points = [], edges = [], polygons = [], animation = null ) {
        this.points = points;
        this.edges = edges;
        this.polygons = polygons;
        this.animation = animation;
    }
}