class Edge {
    constructor(p1 = 0, p2 = 0) {
        this.p1 = p1;
        this.p2 = p2;
    }
}